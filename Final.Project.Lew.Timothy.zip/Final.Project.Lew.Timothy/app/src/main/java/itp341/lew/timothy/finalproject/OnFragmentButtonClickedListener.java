package itp341.lew.timothy.finalproject;

/**
 * Created by timothylew on 4/6/17.
 */

public interface OnFragmentButtonClickedListener {

    // Interface method to force an activity to implement this method.
    public void onFragmentSwitchIndicator(int position);

}
